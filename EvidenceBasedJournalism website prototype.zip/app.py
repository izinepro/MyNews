from flask import Flask, render_template, request, redirect, url_for, flash
from werkzeug.utils import secure_filename
import os
import sqlite3

app = Flask(__name__)
app.secret_key = 'supersecretkey'

# Configuration for uploads
UPLOAD_FOLDER = 'static/uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Database initialization
DATABASE = 'news.db'

def get_db_connection():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

# Routes
@app.route('/')
def home():
    return render_template('home.html')

@app.route('/post-news', methods=['GET', 'POST'])
def post_news():
    if request.method == 'POST':
        headline = request.form['headline']
        description = request.form['description']
        file = request.files['evidence']

        if headline and description and file:
            filename = secure_filename(file.filename)
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))

            # Save to database
            conn = get_db_connection()
            conn.execute(
                'INSERT INTO news (headline, description, evidence) VALUES (?, ?, ?)',
                (headline, description, filename)
            )
            conn.commit()
            conn.close()

            flash('News report submitted successfully!', 'success')
            return redirect(url_for('news_feed'))
        else:
            flash('All fields are required.', 'danger')

    return render_template('post_news.html')

@app.route('/news-feed')
def news_feed():
    conn = get_db_connection()
    news_items = conn.execute('SELECT * FROM news').fetchall()
    conn.close()
    return render_template('news_feed.html', news_items=news_items)

if __name__ == '__main__':
    # Initialize database if not exists
    if not os.path.exists(DATABASE):
        conn = sqlite3.connect(DATABASE)
        conn.execute(
            'CREATE TABLE news (id INTEGER PRIMARY KEY AUTOINCREMENT, headline TEXT, description TEXT, evidence TEXT)'
        )
        conn.close()
    app.run(debug=True)
